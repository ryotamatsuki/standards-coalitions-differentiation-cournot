# Stage25 / JPET manuscript v0.4 — Figure 3 refined

- `stage25_jpet_v04.pdf`: complete 17-page English working paper, Figures 1–3 and Tables 1–2.
- `stage25_jpet_v04.tex`: editable LaTeX source; compile inside this folder using `pdflatex stage25_jpet_v04.tex` twice, with the included `figure3_v04_kappa_eta_phase.pdf` alongside.
- `figure3_v04_kappa_eta_phase.pdf` / `.png`: high-resolution XY phase map (vector PDF + PNG).
- `figure3_data_41x41.npz`: numerical classifications (F/N), 41-point kappa/eta axes, first-pass-vs-refined labels. Codes: 0 SW, 1 SU, 2 IS, 3 unresolved. Final grids contain no observed SU.
- `figure3_depth_convergence_641.json`: 641-depth rechecks of the 28 cells whose classification changed between 81 and 321 depth samples.
- `figure3_design_nash_spotchecks.json`: 240 sampled continuation FOC/global-uniqueness plausibility and positive-output spot checks.
- `phase_model_functions.py` and `figure3_plot_source.py`: source excerpts showing calculation and rendering logic; adjust paths in plotting source to this folder before independent rerun.
- `FIGURE3_V04_REVIEW_QA.md`: limitations, placement, mathematical guardrails, and QA notes.

This is **NOT FOR SUBMISSION** and the phase diagram is **numerically exploratory**, not a mathematically certified phase classification. Further multi-start/continuous-depth/interval verification and formal Stage11 hostile review remain necessary.
