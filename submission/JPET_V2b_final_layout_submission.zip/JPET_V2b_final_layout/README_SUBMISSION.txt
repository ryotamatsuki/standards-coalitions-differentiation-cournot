JPET manuscript package — review and author-signoff only; not submitted.
Compile in this folder with: latexmk -pdf -file-line-error -halt-on-error -interaction=nonstopmode JPET_submission_final.tex
Upload main .tex + paired review PDF; upload the two input/graphics sources as additional LaTeX files as required by Wiley portal.
All three figure PDFs are used by \includegraphics; not generic Supporting Information.
editing_sources contains legacy Figure 3 TikZ for reproduction; manuscript compilation DOES NOT require TikZ.
Funding and competing interests were confirmed by the author. No journal upload or merge performed.
